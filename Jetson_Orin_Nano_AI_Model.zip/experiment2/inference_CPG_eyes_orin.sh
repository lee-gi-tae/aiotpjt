#!/bin/bash

DATASETS=(
    'split_eyes'
)

NUM_CLASSES=(
    2
)

GPU_ID=0
NETWORK_WIDTH_MULTIPLIER=1.0
ARCH='resnet50'
PRED_PATH='/home/jetson/DriverStatus/home/CPG/predict_test'

# Orin Nano 최적화 설정
BATCH_SIZE=16  # Orin Nano는 더 큰 배치 크기 지원
WORKERS=8      # 더 많은 워커 사용 가능
CUDA_DEVICE=0

# Orin Nano GPU 최적화
export CUDA_VISIBLE_DEVICES=$CUDA_DEVICE
export CUDA_LAUNCH_BLOCKING=1

# TensorRT 최적화 (선택사항)
# export TENSORRT_CACHE_PATH=/tmp/tensorrt_cache

CUDA_VISIBLE_DEVICES=$GPU_ID python3 CPG_imagenet_main.py \
    --arch $ARCH \
    --dataset ${DATASETS} --num_classes ${NUM_CLASSES} \
    --load_folder checkpoints/CPG/experiment2/$ARCH/${DATASETS}/gradual_prune \
    --mode inference \
    --jsonfile logs/baseline_imagenet_acc_$ARCH.txt \
    --network_width_multiplier $NETWORK_WIDTH_MULTIPLIER \
    --log_path logs/imagenet_inference.log \
    --pred_path $PRED_PATH \
    --batch_size $BATCH_SIZE \
    --workers $WORKERS \
    --cuda 