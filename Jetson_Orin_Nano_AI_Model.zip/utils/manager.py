import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from tqdm import tqdm
import pdb
from torch.autograd import Variable
from . import Metric, classification_accuracy
from .prune import SparsePruner
from .metrics import fv_evaluate
import models.layers as nl
from models import AngleLoss
from datetime import datetime
from pytz import timezone
import torch.nn.functional as nnf


class Manager(object):
    """Handles training and pruning."""

    def __init__(self, args, model, shared_layer_info, masks, train_loader, val_loader, begin_prune_step, end_prune_step):
        self.args = args
        self.model = model
        self.shared_layer_info = shared_layer_info
        self.inference_dataset_idx = self.model.module.datasets.index(args.dataset) + 1
        self.pruner = SparsePruner(self.model, masks, self.args, begin_prune_step, end_prune_step, self.inference_dataset_idx)
        self.train_loader = train_loader
        self.val_loader   = val_loader

        if args.dataset == 'face_verification':
            self.criterion = AngleLoss()
        elif args.dataset == 'emotion':
            class_counts = torch.from_numpy(np.array([74874, 134415, 25459, 14090, 6378, 3803, 24882]).astype(np.float32))
            class_weights = (torch.sum(class_counts) - class_counts) / class_counts
            self.criterion = nn.CrossEntropyLoss(weight=class_weights.cuda())
        else:
            self.criterion = nn.CrossEntropyLoss()
        return

    def train(self, optimizers, epoch_idx, curr_lrs, curr_prune_step):
        # Set model to training mode
        self.model.train()

        train_loss     = Metric('train_loss')
        train_accuracy = Metric('train_accuracy')

        with tqdm(total=len(self.train_loader),
                  desc='Train Ep. #{}: '.format(epoch_idx + 1),
                  disable=False,
                  ascii=True) as t:
            for batch_idx, (data, target) in enumerate(self.train_loader):
                if self.args.cuda:
                    data, target = data.cuda(), target.cuda()

                optimizers.zero_grad()
                # Do forward-backward.
                output = self.model(data)

                num = data.size(0)
                if self.args.dataset != 'face_verification':
                    train_accuracy.update(classification_accuracy(output, target), num)

                loss = self.criterion(output, target)
                train_loss.update(loss, num)
                loss.backward()

                # Set fixed param grads to 0.
                self.pruner.do_weight_decay_and_make_grads_zero()

                # Gradient is applied across all ranks
                optimizers.step()

                # Set pruned weights to 0.
                if self.args.mode == 'prune':
                    self.pruner.gradually_prune(curr_prune_step)
                    curr_prune_step += 1

                if self.inference_dataset_idx == 1:
                    t.set_postfix({'loss': train_loss.avg.item(),
                                   'accuracy': '{:.2f}'.format(100. * train_accuracy.avg.item()),
                                   'lr': curr_lrs[0],
                                   'sparsity': self.pruner.calculate_sparsity(),
                                   'network_width_mpl': self.args.network_width_multiplier})
                else:
                    t.set_postfix({'loss': train_loss.avg.item(),
                                   'accuracy': '{:.2f}'.format(100. * train_accuracy.avg.item()),
                                   'lr': curr_lrs[0],
                                   'sparsity': self.pruner.calculate_sparsity(),
                                   'network_width_mpl': self.args.network_width_multiplier})
                t.update(1)

        summary = {'loss': '{:.3f}'.format(train_loss.avg.item()),
                   'accuracy': '{:.2f}'.format(100. * train_accuracy.avg.item()),
                   'lr': curr_lrs[0],
                   'sparsity': '{:.3f}'.format(self.pruner.calculate_sparsity()),
                   'network_width_mpl': self.args.network_width_multiplier}

        if self.args.log_path:
            logging.info(('In train()-> Train Ep. #{} '.format(epoch_idx + 1)
                         + ', '.join(['{}: {}'.format(k, v) for k, v in summary.items()])))
        return train_accuracy.avg.item(), curr_prune_step

    #{{{ Evaluate classification
    def validate(self, test_loader, epoch_idx, class_name, biases=None):
        """Performs evaluation."""
        self.pruner.apply_mask()
        self.model.eval()
        val_loss = Metric('val_loss')
        val_accuracy = Metric('val_accuracy')
        if class_name == "eyes":
            classes = ["eye_close", "eye_open"]
            print("(djlee) root@1b6275f38a4e:/home/CPG# sh experiment2/CPG_eyes_validate.sh")
            conf_matrix = torch.zeros(2, 2)
        elif class_name == "face":
            classes = ["down", "front", "left", "right", "up"]
            print("(djlee) root@1b6275f38a4e:/home/CPG# sh experiment2/CPG_face_validate.sh")
            conf_matrix = torch.zeros(5, 5)
        with torch.no_grad():
            for i, (data, target) in enumerate(test_loader):
                if self.args.cuda:
                    data, target = data.cuda(), target.cuda()

                output = self.model(data)
                num = data.size(0)
                pred = torch.max(output, 1)[1]
                prob = nnf.softmax(output, dim=1)
                top_p, top_class = prob.topk(1, dim = 1)

                val_loss.update(self.criterion(output, target), num)
                val_accuracy.update(classification_accuracy(output, target), num)

                date_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                datetimeObjUnlocalized = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
                datetimeObjZH = timezone('Asia/Seoul').localize(datetimeObjUnlocalized)
                date = datetimeObjZH.astimezone(timezone('Asia/Seoul')).strftime("%Y-%m-%d %H:%M:%S %Z%z")

                print(f"[Time] {date}")
                print(f"[File name] {test_loader.dataset.samples[i][0]}")
                print(f"[Target] {classes[target[0]]}")
                print(f"[Prediction] {classes[torch.max(output, 1)[1][0]]} ({top_p.cpu().numpy()[0][0]})")
                
                if class_name == "eyes":
                    for t, p in zip(target, pred):
                        conf_matrix[t, p] += 1
                elif class_name == "face":
                    for t, p in zip(target, pred):
                        conf_matrix[t, p] += 1
                print()

        summary = {'loss': '{:.3f}'.format(val_loss.avg.item()),
                   'accuracy': '{:.2f}'.format(100. * val_accuracy.avg.item())}
        if self.inference_dataset_idx != 1:
            summary['shared_ratio'] = '{:.3f}'.format(self.pruner.calculate_shared_part_ratio())

        if self.args.log_path:
            logging.info(('\nSummary: ' + ', '.join(['{}: {}'.format(k, v) for k, v in summary.items()])))
        if class_name == "eyes":
            print('Confusion matrix')
            print("eyes_close", "eyes_open")
            print(conf_matrix.cpu().numpy())
        elif class_name == "face":
            print('Confusion matrix')
            print("down", "front", "left", "right", "up")
            print(conf_matrix.cpu().numpy())
        return val_accuracy.avg.item()
    #}}}

    #{{{ Evaluate LFW
    def evalLFW(self, epoch_idx):
        distance_metric = True
        subtract_mean   = False
        self.pruner.apply_mask()
        self.model.eval() # switch to evaluate mode
        labels, embedding_list_a, embedding_list_b = [], [], []
        with torch.no_grad():
            with tqdm(total=len(self.val_loader),
                      desc='Validate Epoch  #{}: '.format(epoch_idx + 1),
                      ascii=True) as t:
                for batch_idx, (data_a, data_p, label) in enumerate(self.val_loader):
                    data_a, data_p = data_a.cuda(), data_p.cuda()
                    data_a, data_p, label = Variable(data_a, volatile=True), \
                                            Variable(data_p, volatile=True), Variable(label)
                    # ==== compute output ====
                    out_a = self.model.module.forward_to_embeddings(data_a)
                    out_p = self.model.module.forward_to_embeddings(data_p)
                    # do L2 normalization for features
                    if not distance_metric:
                        out_a = F.normalize(out_a, p=2, dim=1)
                        out_p = F.normalize(out_p, p=2, dim=1)
                    out_a = out_a.data.cpu().numpy()
                    out_p = out_p.data.cpu().numpy()

                    embedding_list_a.append(out_a)
                    embedding_list_b.append(out_p)
                    # ========================
                    labels.append(label.data.cpu().numpy())
                    t.update(1)

        labels = np.array([sublabel for label in labels for sublabel in label])
        embedding_list_a = np.array([item for embedding in embedding_list_a for item in embedding])
        embedding_list_b = np.array([item for embedding in embedding_list_b for item in embedding])
        tpr, fpr, accuracy, val, val_std, far = fv_evaluate(embedding_list_a, embedding_list_b, labels,
                                                distance_metric=distance_metric, subtract_mean=subtract_mean)
        print('In evalLFW(): Test set: Accuracy: {:.5f}+-{:.5f}'.format(np.mean(accuracy),np.std(accuracy)))
        logging.info(('In evalLFW()-> Validate Epoch #{} '.format(epoch_idx + 1)
                     + 'Test set: Accuracy: {:.5f}+-{:.5f}, '.format(np.mean(accuracy),np.std(accuracy))
                     + 'task_ratio: {:.2f}'.format(self.pruner.calculate_curr_task_ratio())))
        return np.mean(accuracy)
    #}}}

    def save_checkpoint(self, optimizers, epoch_idx, save_folder):
        """Saves model to file."""
        filepath = self.args.checkpoint_format.format(save_folder=save_folder, epoch=epoch_idx + 1)

        for name, module in self.model.module.named_modules():
            if isinstance(module, nl.SharableConv2d) or isinstance(module, nl.SharableLinear):
                if module.bias is not None:
                    self.shared_layer_info[self.args.dataset][
                        'bias'][name] = module.bias
                if module.piggymask is not None:
                    self.shared_layer_info[self.args.dataset][
                        'piggymask'][name] = module.piggymask
            elif isinstance(module, nn.BatchNorm2d):
                self.shared_layer_info[self.args.dataset][
                    'bn_layer_running_mean'][name] = module.running_mean
                self.shared_layer_info[self.args.dataset][
                    'bn_layer_running_var'][name] = module.running_var
                self.shared_layer_info[self.args.dataset][
                    'bn_layer_weight'][name] = module.weight
                self.shared_layer_info[self.args.dataset][
                    'bn_layer_bias'][name] = module.bias
            elif isinstance(module, nn.PReLU):
                self.shared_layer_info[self.args.dataset][
                    'prelu_layer_weight'][name] = module.weight

        checkpoint = {
            'model_state_dict': self.model.module.state_dict(),
            'dataset_history': self.model.module.datasets,
            'dataset2num_classes': self.model.module.dataset2num_classes,
            'masks': self.pruner.masks,
            'shared_layer_info': self.shared_layer_info
        }
        torch.save(checkpoint, filepath)
        return

    def load_checkpoint(self, optimizers, resume_from_epoch, save_folder):

        if resume_from_epoch > 0:
            filepath = self.args.checkpoint_format.format(save_folder=save_folder, epoch=resume_from_epoch)
            checkpoint = torch.load(filepath)
            checkpoint_keys = checkpoint.keys()
            state_dict = checkpoint['model_state_dict']
            curr_model_state_dict = self.model.module.state_dict()

            for name, param in state_dict.items():
                if ('piggymask' in name or name == 'classifier.weight' or name == 'classifier.bias' or
                    (name == 'classifier.0.weight' or name == 'classifier.0.bias' or name == 'classifier.1.weight')):
                    # I DONT WANT TO DO THIS! QQ That last 3 exprs are for anglelinear and embeddings
                    continue
                elif len(curr_model_state_dict[name].size()) == 4:
                    # Conv layer
                    curr_model_state_dict[name][:param.size(0), :param.size(1), :, :].copy_(param)
                elif len(curr_model_state_dict[name].size()) == 2 and 'features' in name:
                    # FC conv (feature layer)
                    curr_model_state_dict[name][:param.size(0), :param.size(1)].copy_(param)
                elif len(curr_model_state_dict[name].size()) == 1:
                    # bn and prelu layer
                    curr_model_state_dict[name][:param.size(0)].copy_(param)
                elif 'classifiers' in name:
                    curr_model_state_dict[name][:param.size(0), :param.size(1)].copy_(param)
                else:
                    try:
                        curr_model_state_dict[name].copy_(param)
                    except:
                        pdb.set_trace()
                        print("There is some corner case that we haven't tackled")
        return

    def load_checkpoint_only_for_evaluate(self, resume_from_epoch, save_folder):

        if resume_from_epoch > 0:
            filepath = self.args.checkpoint_format.format(save_folder=save_folder, epoch=resume_from_epoch)
            checkpoint = torch.load(filepath)
            checkpoint_keys = checkpoint.keys()
            state_dict = checkpoint['model_state_dict']
            curr_model_state_dict = self.model.module.state_dict()

            for name, param in state_dict.items():
                if 'piggymask' in name: # we load piggymask value in main.py
                    continue

                if (name == 'classifier.weight' or name == 'classifier.bias' or
                    (name == 'classifier.0.weight' or name == 'classifier.0.bias' or name == 'classifier.1.weight')):
                     # I DONT WANT TO DO THIS! QQ That last 3 exprs are for anglelinear and embeddings
                    continue

                elif len(curr_model_state_dict[name].size()) == 4:
                    # Conv layer
                    curr_model_state_dict[name].copy_(
                            param[:curr_model_state_dict[name].size(0), :curr_model_state_dict[name].size(1), :, :])

                elif len(curr_model_state_dict[name].size()) == 2 and 'features' in name:
                    # FC conv (feature layer)
                    curr_model_state_dict[name].copy_(
                            param[:curr_model_state_dict[name].size(0), :curr_model_state_dict[name].size(1)])

                elif len(curr_model_state_dict[name].size()) == 1:
                    # bn and prelu layer
                    curr_model_state_dict[name].copy_(param[:curr_model_state_dict[name].size(0)])

                else:
                    curr_model_state_dict[name].copy_(param)

            # load the batch norm params and bias in convolution in correspond to curr dataset
            for name, module in self.model.module.named_modules():
                if isinstance(module, nl.SharableConv2d) or isinstance(module, nl.SharableLinear):
                    if module.bias is not None:
                        module.bias = self.shared_layer_info[self.args.dataset]['bias'][name]

                elif isinstance(module, nn.BatchNorm2d):
                    module.running_mean = self.shared_layer_info[self.args.dataset][
                        'bn_layer_running_mean'][name]
                    module.running_var = self.shared_layer_info[self.args.dataset][
                        'bn_layer_running_var'][name]
                    module.weight = self.shared_layer_info[self.args.dataset][
                        'bn_layer_weight'][name]
                    module.bias = self.shared_layer_info[self.args.dataset][
                        'bn_layer_bias'][name]

                elif isinstance(module, nn.PReLU):
                    module.weight = self.shared_layer_info[self.args.dataset][
                        'prelu_layer_weight'][name]
        return

    def predict(self, predict_loader, epoch_idx, dataset):
        if "face" in dataset:
            classes = ("down", "front", "left", "right", "up")
        elif "eyes" in dataset:
            classes = ("eyes_close", "eyes_open")

        """Performs evaluation."""
        self.model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for data, target in predict_loader:
                if self.args.cuda:
                    data, target = data.cuda(), target.cuda()

                output = self.model(data)
                predicted = torch.max(output, 1)[1]               
                print("Predicted:", ", ".join(classes[predicted[j]] for j in range(len(predicted))))

    def confusion_matrix(self, samples, classes, pred, target):
        nb_samples = samples
        nb_classes = classes

        conf_matrix = torch.zeros(nb_classes, nb_classes)
        for t, p in zip(target, pred):
            conf_matrix[t, p] += 1

        print('Confusion matrix\n', conf_matrix)

        TP = conf_matrix.diag()
        for c in range(nb_classes):
            idx = torch.ones(nb_classes).byte()
            idx[c] = 0
            # all non-class samples classified as non-class
            TN = conf_matrix[idx.nonzero()[:, None], idx.nonzero()].sum() #conf_matrix[idx[:, None], idx].sum() - conf_matrix[idx, c].sum()
            # all non-class samples classified as class
            FP = conf_matrix[idx, c].sum()
            # all class samples not classified as class
            FN = conf_matrix[c, idx].sum()
            
            print('Class {}\nTP {}, TN {}, FP {}, FN {}'.format(
                c, TP[c], TN, FP, FN))