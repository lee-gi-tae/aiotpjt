# Jetson Orin Nano 운전자 상태 인식 AI 모델

## 📋 개요
이 모델은 운전자의 얼굴 방향과 눈 상태를 실시간으로 인식하는 AI 모델입니다.

## 🎯 기능
- **얼굴 방향 인식**: 정면, 상/하/좌/우 (5개 클래스)
- **눈 상태 인식**: 뜸/감음 (2개 클래스)

## 📊 성능
- **얼굴 방향 정확도**: 99.2%
- **눈 상태 정확도**: 99.79%
- **예상 FPS**: 50-100 FPS (Jetson Orin Nano)

## 🛠️ 설치 방법

### 1. 시스템 요구사항
- Jetson Orin Nano
- JetPack 5.0 이상
- Python 3.8 이상

### 2. Python 라이브러리 설치
```bash
# 시스템 업데이트
sudo apt-get update
sudo apt-get install python3-pip python3-dev

# Jetson용 PyTorch 설치
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# 추가 라이브러리
pip3 install numpy tqdm pillow opencv-python
```

### 3. 실행 권한 부여
```bash
chmod +x experiment2/inference_CPG_face_orin.sh
chmod +x experiment2/inference_CPG_eyes_orin.sh
```

## 🚀 사용 방법

### 얼굴 방향 인식 실행
```bash
cd experiment2
./inference_CPG_face_orin.sh
```

### 눈 상태 인식 실행
```bash
cd experiment2
./inference_CPG_eyes_orin.sh
```

## 📁 파일 구조
```
Jetson_Orin_Nano_AI_Model/
├── experiment2/
│   ├── CPG_imagenet_main.py (메인 실행 파일)
│   ├── inference_CPG_face_orin.sh (얼굴 방향 인식)
│   └── inference_CPG_eyes_orin.sh (눈 상태 인식)
├── models/ (모델 정의 파일들)
├── utils/ (유틸리티 함수들)
├── checkpoints/
│   ├── checkpoint-9.pth.tar (얼굴 방향 모델)
│   └── checkpoint-10.pth.tar (눈 상태 모델)
└── predict_test/ (결과 저장 폴더)
```

## ⚙️ 설정 옵션

### 배치 크기 조정
- 기본값: 16
- 메모리 부족 시: 8로 줄이기
- 성능 향상 시: 32로 늘리기

### GPU 설정
- GPU ID: 0 (기본값)
- CUDA 가속: 자동 활성화

## 📈 성능 최적화

### 1. GPU 모드 설정
```bash
# 최대 성능 모드
sudo nvpmodel -m 0
sudo jetson_clocks
```

### 2. 메모리 최적화
```bash
# 스왑 메모리 설정 (필요시)
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

## 🔧 문제 해결

### 1. CUDA 오류
```bash
# CUDA 버전 확인
nvcc --version
python3 -c "import torch; print(torch.version.cuda)"
```

### 2. 메모리 부족
- 배치 크기를 8로 줄이기
- 워커 수를 4로 줄이기

### 3. 성능 저하
- GPU 모드를 최대 성능으로 설정
- 불필요한 프로세스 종료

## 📞 지원
- 모델 성능: 99% 이상의 정확도
- 실시간 처리: 50-100 FPS
- 메모리 사용량: 약 500MB

## 📄 라이선스
BSD-3-Clause License 